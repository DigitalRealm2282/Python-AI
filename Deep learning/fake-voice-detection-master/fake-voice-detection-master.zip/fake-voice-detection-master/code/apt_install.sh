apt-get update
yes | apt-get install libsndfile1